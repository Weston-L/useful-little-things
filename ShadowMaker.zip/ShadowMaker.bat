@echo off
python "ShadowMaker.py" %*
pause
